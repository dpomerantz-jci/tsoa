export type UnspecifiedObject = { [key: string]: unknown };
